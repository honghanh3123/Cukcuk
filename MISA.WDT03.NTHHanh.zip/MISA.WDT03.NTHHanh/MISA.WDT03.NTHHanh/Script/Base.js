﻿class Base {
    constructor() {
    }

    loadData() {
        var pageIndex = $('.page-index').val();
        var pageSize = $('.page-size option:selected').val();
        $.ajax({
            method: 'GET',
            url: '/customers/{0}/{1}'.format(pageIndex, pageSize),
            success: function (res) {
                $('.main-table tbody').empty();
                if (res.Success) {
                    var data = res.Data;

                    var fields = $("th[fieldName]");
                    $.each(data, function (index, item) {

                        var rowHTML = $('<tr></tr>').data("recordid", item["CustomerID"]);
                        $.each(fields, function (fieldIndex, fieldItem) {
                            var fieldName = fieldItem.getAttribute('fieldName');

                            var fieldValue = item[fieldName];
                            if (fieldName === "IsFiveFood" || fieldName === "IsUnFollow") {
                                let classCheckbox = fieldValue ? "check" : "uncheck"
                                return rowHTML.append('<td class = "{0}"></td>'.format(`icon-tick ${classCheckbox}`));
                            }
                            return rowHTML.append('<td class = "{1}"> {0}</td>'.format(fieldValue || "", fieldName));
                        });
                        $('.main-table tbody').append(rowHTML);
                    })
                    $('#loading').hide();
                } else {
                    alert(res.Message);
                }
            },
            error: function (res) {
                alert("Dịch vụ đang lỗi");
            }
        })
    }
}