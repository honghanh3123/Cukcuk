﻿$(document).ready(function () {

})

class Customer extends Base {
    constructor() {
        super();
        this.validateInput = ["username", "phone", "customerCode"]
        this.loadData();
        this.InitEvent();
        this.pageMaximum();
    }

    /**
     * Hàm tạo sự kiện
     * */

    InitEvent() {
        $("#datepicker").datepicker();
        $(document).on('click', 'tr', {
            'jobject': 12345,
            'name': "Hong Hanh"
        }, this.rowOnClick);

        $(document).on('click', '.icon-tick', this.tickRow);

        $(document).on('click', '.add-new', this.openDialog);

        $(document).on('click', '.edit', this.openEditDialog);

        $(document).on('click', '.delete', this.clickDelete());

        $(document).on('click', '.save', this.saveCustomer);

        $(document).on('click', '.delete-x', this.closeDialog);

        $(document).on('click', 'button-delete', this.deleteCustomers);

        $(document).on('click', 'button-cancel', this.closeDialog);

        $(document).on('keyup', '.page-index', this.pagingData);

        $(document).on('click', '.next', this.nextPagingData);

        $(document).on('click', '.previous', this.prevPagingData);

        $(document).on('click', '.page-start', this.startPagingData);

        $(document).on('click', '.page-end', this.endPagingData);

        $(document).on('change', '.page-size', this.onChangePageSize);

        //$('#page-number').pageMaximum();

        this.validateInput.map(inputName => {
            $(document).on('focusout', `#validate-input-${inputName}`, this.warning(inputName));
            $(`#warning-${inputName}`).hover(this.showWarningInfo(inputName), this.hideWarningInfo(inputName))
        })
    }

    onChangePageSize = (event) => {
        this.pageMaximum(event.target.value);
        this.loadData();
    }

    startPagingData = () => {
        $('.page-index').val(1);
        this.loadData();
    }

    endPagingData = () => {
        $('.page-index').val($('#page-number').text());
        this.loadData();
    }

    nextPagingData = () => {
        var pageIndex = $('.page-index').val();
        if (Number(pageIndex) < Number($('#page-number').text())) {
            $('.page-index').val(Number(pageIndex) + 1);
            this.loadData();
        }
    }

    prevPagingData = () => {
        var pageIndex = $('.page-index').val();
        if (Number(pageIndex) > 1) {
            $('.page-index').val(Number(pageIndex) - 1);
            this.loadData();
        }
    }

    pageMaximum(newPageSize) {
        $.ajax({
            method: 'GET',
            url: '/customers',
            success: function (res) {
                if (res.Success) {
                    var data = res.Data;
                    var pageSize = newPageSize || $('.page-size option:selected').val();
                    var length = data.length;
                    $('#page-number').text(Math.ceil(length / pageSize));
                }
            },
            error: function (res) {
                alert("Dịch vụ đang lỗi");
            }
        })
    }

    /**
     * Hàm thực hiện phân trang
     * Người tạo: Nguyễn Thị Hồng Hạnh
     * Ngày tạo: 27/08/2019
     * @param {any} event
     */
    pagingData = (event) => {
        var pageIndex = Number(event.target.value);
        if (event.keyCode === 13 && pageIndex > 0 && pageIndex <= Number($('#page-number').text())) {
            this.loadData();
        }
    }

    /**
     * Hàm thực hiện xóa lấy id của khách hàng muốn xóa và hiển thị dialog xóa
     * Người tạo: Nguyễn Thị Hồng Hạnh
     * Ngày tạo: 26/08/2019
     * */

    clickDelete() {
        return () => {
            var listCustomerID = [];
            var listCustomerCode = [];
            var listRow = $('.selected');

            $.each(listRow, function (index, item) {
                var customerid = $(item).data('recordid');
                var firstTd = $(item).children()[0]
                listCustomerCode.push($(firstTd).text());
                listCustomerID.push(customerid);
            })

            $("#list-custumers").text(listCustomerCode.join(", "));

            if (listRow.length) {
                $(".opacity").show();
                $("#dialog-delete").dialog({
                    title: "Khách hàng",
                    open: true,
                    resizable: false,
                    height: "auto",
                    width: 400,
                    close: () => {
                        $(".opacity").hide();
                    },
                    buttons: {
                        "Có": () => {
                            this.deleteCustomers(listCustomerID)
                        },
                        "Không": () => {
                            $("#dialog-delete").dialog("close")
                            $(".opacity").hide();
                        }
                    }
                })
            }
        }
    }

    /**
     * Hàm thực hiện xóa khách hàng
     * Người tạo: Nguyễn Thị Hồng Hạnh
     * Ngày tạo: 26/8/2019
     * @param {any} listCustomerID
     */
    deleteCustomers(listCustomerID) {
        $.ajax({
            method: 'DELETE',
            url: '/customers',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(listCustomerID),
            success: (res) => {
                this.loadData();
                $("#dialog-delete").dialog("close");
            },
            error: () => {
                alert("Da co loi xay ra");
            }
        });
    }

    /**
     * Hàm thực hiện đóng cửa sổ dialog xóa khách hàng
     * Người tạo: Nguyễn Thị Hồng Hạnh
     * Ngày tạo: 26/08/2019
     * */
    cancelDialogDelete() {
        this.closeDialog();
    }

    /**
     * Hàm thực hiện sửa thông tin khách hàng
     * Người tạo: Nguyễn Thị Hồng Hạnh
     * Ngày tạo: 25/08/2019
     * */
    openEditDialog = () => {
        let rowSelect = $(".selected")
        if (rowSelect.length === 1) {
            $("#group-buton").addClass("update")
            let CustomerId = $(rowSelect[0]).data("recordid");
            $.ajax({
                method: 'GET',
                url: '/customers/' + CustomerId,
                contentType: "application/json; charset=utf-8",
                success: (res) => {
                    this.openDialog();

                    var listRow = $('input[property]');
                    $.each(listRow, (index, item) => {
                        var propertyName = item.getAttribute('property');
                        $(item).val(res.Data[propertyName])

                    });
                    $("textarea[property]").val(res.Data.Note);
                },
                error: () => {
                    alert("Da co loi xay ra");
                }
            });
        }
    }

    showWarningInfo(inputName) {
        return () => {
            $("#warning-text-" + inputName).show();
            $("#warning-info-" + inputName).addClass("warning-info")
        }
    }

    hideWarningInfo(inputName) {
        return () => {
            $("#warning-text-" + inputName).hide();
            $("#warning-info-" + inputName).removeClass("warning-info")
        }
    }

    /**
     * Hàm thực hiện lưu thông tin khách hàng
     * Người tạo: 23/8/2019
     * Ngày tạo: Nguyễn Thị Hồng Hạnh
     * */
    saveCustomer = () => {
        var method = $("#group-buton").hasClass("update") ? "PUT" : "POST";

        var listRow = $('input[property]');
        var object = {};
        $.each(listRow, (index, item) => {
            var propertyName = item.getAttribute('property');
            var value = $(item).val() // this la item - input, set gia tri them val("abc")
            object[propertyName] = value;
        });

        object.Note = $("textarea[property]").val();
        object.IsFiveFood = true;
        object.IsUnFollow = true;

        if (method === "PUT") {
            let rowSelect = $(".selected");
            let CustomerId = $(rowSelect[0]).data("recordid");
            object.CustomerID = CustomerId
        }

        $.ajax({
            method: method,
            url: '/customers',
            data: JSON.stringify(object),
            contentType: "application/json; charset=utf-8",
            success: () => {
                $('#dialog').dialog('close');
                $('.main-table tbody').empty()
                if ($("#group-buton").hasClass("update")) {
                    $("#group-buton").removeClass("update")
                }
                this.loadData();
            },
            error: () => {
                alert("Da co loi xay ra");
            }
        });
    }

    /**
     * Hàm thực hiện cảnh báo khi chưa điền thông tin ở bảng dialog
     * Ngày tạo: 23/08/2019
     * Người tạo: Nguyễn Thị Hồng Hạnh
     * */
    warning(inputName) {
        return function () {
            if (!$(this).val()) {
                $("#warning-" + inputName).show();
                return $(this).addClass("input-warning")
            }
            $("#warning-" + inputName).hide();
            return $(this).removeClass("input-warning")
        }
    }

    /**
     * Hàm thực hiện mở dialog
     * Người tạo: Nguyễn Thị Hồng Hạnh
     * Ngày tạo: 23/08/2019
     */
    openDialog = () => {
        $("#dialog").dialog({
            title: "Khách hàng",
            height: 353,
            width: 700,
            close: () => {
                $(".opacity").hide();
                this.validateInput.map(inputName => {
                    $("#warning-" + inputName).hide();
                    $("#validate-input-" + inputName).removeClass("input-warning")

                    var listRow = $('input[property]');
                    $.each(listRow, (index, item) => {
                        var propertyName = item.getAttribute('property');
                        $(item).val("")

                    });
                    $("textarea[property]").val("");
                })
            },
        });
        $(".opacity").show();
    }

    closeDialog = () => {
        $("#dialog").dialog("close")
        if ($("#group-buton").hasClass("update")) {
            $("#group-buton").removeClass("update")
        }
        this.validateInput.map(inputName => {
            $("#warning-" + inputName).hide();
            $("#validate-input-" + inputName).removeClass("input-warning")
        })
        var listRow = $('input[property]');
        $.each(listRow, (index, item) => {
            var propertyName = item.getAttribute('property');
            $(item).val("")

        });
        $("textarea[property]").val("");
    }

    /**
     * Hàm thực hiện thông báo khi click vào một hàm
     * Ngày tạo: 23/08/2019
     * Người tạo: Nguyễn Thị Hồng Hạnh
     * */
    rowOnClick(event) {
        if (event.ctrlKey) {
            if ($(this).hasClass("selected")) {
                return $(this).removeClass("selected")
            }
            return $(this).addClass('selected');
        }
        if ($(this).hasClass("selected")) {
            return $(this).removeClass("selected")
        }
        $('.main-table tbody tr').removeClass('selected');
        $(this).addClass('selected');
    }

    /**
     * Hàm thực hiện khi click vào checkbox
     * Ngày tạo: 23/08/2019
     * Người tạo: Nguyễn Thị Hồng Hạnh
     * */
    tickRow(event) {
        var currTick = event.currentTarget.classList[1];
        if (currTick === 'uncheck') {
            $(this).removeClass('uncheck');
            $(this).addClass('check');
        } else {
            $(this).removeClass('check');
            $(this).addClass('uncheck');
        }
    }
}

var customer = new Customer();