﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using MISA.BL;
using MISA.DL;
using MISA.Entities;
using MISA.Entities.Dictionary;
using MISA.WDT03.NTHHanh.Models;
using MISA.WDT03.NTHHanh.Properties;

namespace MISA.WDT03.NTHHanh.Controllers
{
    public class CustomersController : ApiController
    {
        private CustomerDL _customerDL = new CustomerDL();
        private CustomerBL _customerBL = new CustomerBL();

        /// <summary>
        /// Hàm thực hiện lấy dữ liệu khách hàng
        /// Người tạo: Nguyễn Thị Hồng Hạnh
        /// Ngày tạo: 26/8/2019
        /// </summary>
        /// <returns></returns>

        [Route("customers/{pageIndex}/{pageSize}")]
        [HttpGet]
        public async Task<AjaxResult> GetCustomers([FromUri] int pageIndex, int pageSize)
        {
            //await Task.Delay(1000);
            var _ajaxResult = new AjaxResult();
            try
            {
                _ajaxResult.Data = _customerBL.PagingData(pageIndex, pageSize);
            }
            catch (Exception ex)
            {
                _ajaxResult.Success = false;
                _ajaxResult.Data = ex;
                _ajaxResult.Message = Resources.erroTV;
            }
            return _ajaxResult;
        }
        /// <summary>
        /// Hàm thực hiện lấy dữ liệu
        /// Ngày tạo: 22/8/2019
        /// Người tạo: Nguyễn Thị Hồng Hạnh
        /// </summary>
        /// <returns></returns>
        [Route("customers")]
        [HttpGet]
        public AjaxResult GetCustomer()
        {
            var _ajaxResult = new AjaxResult();
            try
            {
                _ajaxResult.Data = _customerDL.GetCustomerData();
            }
            catch (Exception ex)
            {
                _ajaxResult.Success = false;
                _ajaxResult.Data = ex;
                _ajaxResult.Message = Resources.erroTV;
            }
            return _ajaxResult;
        }

        /// <summary>
        /// Hàm thực hiện lấy thông tin khách hàng từ CustomerID
        /// Người tạo: Nguyễn Thị Hồng Hạnh
        /// Ngày tạo: 23/8/2019
        /// </summary>
        /// <param name="_customerID"></param>
        /// <returns></returns>
        [Route("customers/{_customerID}")]
        [HttpGet]
        public AjaxResult GetCustomerByCustomerID(Guid _customerID)
        {
            var _ajaxResult = new AjaxResult();
            try
            {
                _ajaxResult.Data = _customerDL.GetCustomerByCustomerID(_customerID);
            }
            catch (Exception ex)
            {
                _ajaxResult.Success = false;
                _ajaxResult.Data = ex;
                _ajaxResult.Message = Resources.erroTV;
            }
            return _ajaxResult;
        }

        /// <summary>
        /// Hàm thực hiện thêm mới khách hàng
        /// Ngày tạo: 24/8/2019
        /// Người tạo: Nguyễn Thị Hồng Hạnh
        /// </summary>
        /// <param name="_customeritem"></param>
        /// <returns></returns>
        [Route("customers")]
        [HttpPost]
        public AjaxResult Post([FromBody] Customer _customeritem)
        {
            var _ajaxResult = new AjaxResult();
            try
            {
                _customerDL.AddCustomer(_customeritem);
            }
            catch (Exception ex)
            {
                _ajaxResult.Success = false;
                _ajaxResult.Data = ex;
                _ajaxResult.Message = Resources.erroTV;
            }
            _ajaxResult.Data = _customeritem;
            return _ajaxResult;
        }

        /// <summary>
        /// Hàm thực hiện sửa đổi thông tin khách hàng
        /// Người tạo: Nguyễn Thị Hồng Hạnh
        /// Ngày tạo: 25/8/2019
        /// </summary>
        /// <param name="_customeritem"></param>
        /// <returns></returns>
        [Route("customers")]
        [HttpPut]
        public AjaxResult Put([FromBody] Customer _customeritem)
        {
            var _ajaxResult = new AjaxResult();
            try
            {
                _customerDL.UpdateCustomer(_customeritem);
            }
            catch (Exception ex)
            {
                _ajaxResult.Success = false;
                _ajaxResult.Data = ex;
                _ajaxResult.Message = Resources.erroTV;
            }
            return _ajaxResult;
        }

        /// <summary>
        /// Hàm thực hiện xóa khách hàng
        /// Người tạo: Nguyễn Thị Hồng Hạnh
        /// Ngày tạo: Ngày 25/8/2019
        /// </summary>
        /// <param name="_customerids"></param>
        /// <returns></returns>
        [Route("customers")]
        [HttpDelete]
        public AjaxResult DeleteCustomers([FromBody] List<Guid> _customerids)
        {
            var _ajaxResult = new AjaxResult();
            try
            {
                _customerDL.DeleteCustomer(_customerids);
            }
            catch (Exception ex)
            {
                _ajaxResult.Success = false;
                _ajaxResult.Data = ex;
                _ajaxResult.Message = Resources.erroTV;
            }
            return _ajaxResult;
        }
    }
}